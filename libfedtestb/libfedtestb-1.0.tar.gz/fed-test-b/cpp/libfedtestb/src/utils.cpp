
#include <fedtest/a/utils.hpp>

#include "fedtest/b/utils.hpp"

int fedtestb::utils::baz()
{
    return fedtesta::utils::foo() + 42;
}

