
#ifndef FEDTESTB_HPP
#define FEDTESTB_HPP

namespace fedtestb {
    namespace utils {

        int baz();
    }
}

#endif// FEDTESTB_HPP
