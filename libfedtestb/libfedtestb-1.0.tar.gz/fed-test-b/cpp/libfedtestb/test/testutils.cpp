#include <gtest/gtest.h>
#include <gmock/gmock.h>

#include "fedtest/b/utils.hpp"

using namespace ::testing;
using namespace fedtestb::utils;

class UtilsTest : public Test
{
public:
};

TEST_F(UtilsTest, Baz)
{
    EXPECT_EQ(84, baz());
}

