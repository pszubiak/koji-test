#include <iostream>
#include <fedtest/b/utils.hpp>

using namespace std;
using namespace fedtestb::utils;

int main(int argc, char* argv[]) {
    cout << "FedTestB::Utils::baz says " << baz() << endl;
}
