#include <gtest/gtest.h>
#include <gmock/gmock.h>

#include "fedtest/a/utils.hpp"

using namespace ::testing;
using namespace fedtesta::utils;

class UtilsTest : public Test
{
public:
};

TEST_F(UtilsTest, Foo)
{
    EXPECT_EQ(42, foo());
}

TEST_F(UtilsTest, Bar)
{
    EXPECT_EQ(-42, Bar().getFoo());
}

