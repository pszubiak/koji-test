
#include "fedtest/a/utils.hpp"

int fedtesta::utils::foo()
{
    return 42;
}

fedtesta::utils::Bar::Bar()
{
}


int fedtesta::utils::Bar::getFoo()
{
    return -42;
}
