
#ifndef FEDTESTA_HPP
#define FEDTESTA_HPP

namespace fedtesta {
    namespace utils {

        int foo();

        class Base {
        public:
            ~Base() {}
            virtual int getFoo() = 0;
        };

        class Bar : Base {
        public:
            Bar();
            virtual int getFoo();
        };
    }
}

#endif// FEDTESTA_HPP
